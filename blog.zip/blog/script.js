document.addEventListener("DOMContentLoaded", function () {
    // Handle Like Button Click
    document.querySelectorAll(".like-btn").forEach(button => {
        button.addEventListener("click", function () {
            let blog_id = this.dataset.blogId;
            let user_id = this.dataset.userId;

            if (!user_id) {
                alert("You need to login to like this post.");
                return;
            }

            fetch("like.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "blog_id=" + blog_id + "&user_id=" + user_id
            })
            .then(response => response.text())
            .then(data => {
                document.querySelector("#likes-" + blog_id).innerHTML = data;
            });
        });
    });

    // Handle Comment Form Submission
    document.querySelectorAll(".comment-form").forEach(form => {
        form.addEventListener("submit", function (event) {
            event.preventDefault();
            
            let blog_id = this.querySelector("[name='blog_id']").value;
            let comment_text = this.querySelector("[name='comment_text']").value;
            let user_id = this.querySelector("[name='user_id']").value;

            if (!user_id) {
                alert("You need to login to comment.");
                return;
            }

            fetch("comment.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "blog_id=" + blog_id + "&comment_text=" + encodeURIComponent(comment_text) + "&user_id=" + user_id
            })
            .then(response => response.text())
            .then(data => {
                document.querySelector("#comments-" + blog_id).innerHTML = data;
                this.querySelector("[name='comment_text']").value = ""; // Clear input
            });
        });
    });
});
