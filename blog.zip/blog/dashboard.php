<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Fetch blogs from the database
$sql = "SELECT blogs.*, users.name FROM blogs 
        JOIN users ON blogs.user_id = users.id 
        ORDER BY blogs.created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Website</title>
    <style>
        body {
            margin: 0;
            font-family: 'poppins', sans-serif;
            background-color: #f4f4f4;
        }

        .dashboard {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            width: auto;
            background: #fff;
            padding: 10px;
        }

        .dashboard .heading h1 {
            color: #333;
            font-size: 24px;
        }

        .buttons {
            display: flex;
            gap: 10px;
        }

        .dashboard .buttons a {
            display: inline-block;
            padding: 10px 15px;
            background: #ff6b6b;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .dashboard .buttons a:hover {
            background: #e05252;
        }

        
        .container {
            padding: 20px;
            font-family: Arial, sans-serif;
        }

        .blog-container {
            display: flex;
            flex-wrap: wrap; /* Allows items to wrap on smaller screens */
            gap: 20px; /* Adds space between blog cards */
            justify-content: center; /* Center-aligns the items */
        }

        .blog-card {
            flex: 1 1 calc(33.333% - 40px); /* Ensures 3 columns on larger screens */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Adds a subtle shadow for styling */
            border-radius: 8px;
            overflow: hidden;
            background-color: #fff;
            max-width: 300px;
            min-width: 250px;
            display: flex;
            flex-direction: column;
        }

        .blog-content {
            padding: 15px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .blog-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .blog-description {
            font-size: 14px;
            color: #555;
            margin: 0;
        }



        /* Responsive behavior for smaller screens */
        @media (max-width: 768px) {
            .blog-card {
                flex: 1 1 calc(50% - 40px); /* Adjust to 2 columns */
            }
        }

        @media (max-width: 480px) {
            .blog-card {
                flex: 1 1 100%; /* Stacks items in a single column */
            }
        }


        .read-more {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 12px;
            background: #007BFF;
            color: #fff;
            width:100px;
            text-decoration: none;
            border-radius: 5px;
        }

        .read-more:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>
    <div class="dashboard">
        <div class="heading">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['name']); ?>!</h1>
        </div>
        <div class="buttons">
            <a href="add_blog.php">Add blogs</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <h1>Latest Blogs</h1>
        <div class="blog-container">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class="blog-card">
                        <div class="blog-content">
                            <h3 class="blog-title"><?= htmlspecialchars($row['title']); ?></h3>
                            <p class="blog-description"><?= htmlspecialchars(substr($row['content'], 0, 100)) . "..."; ?></p>
                            <a href="view_blog.php?id=<?= $row['id']; ?>" class="read-more">Read More</a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo "<p>No blogs found.</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>
