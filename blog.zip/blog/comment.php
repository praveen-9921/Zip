<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) exit();

$blog_id = $_POST['blog_id'];
$user_id = $_SESSION['user_id'];
$comment_text = $_POST['comment_text'];

$sql = "INSERT INTO comments (blog_id, user_id, comment_text) VALUES ('$blog_id', '$user_id', '$comment_text')";
$conn->query($sql);
?>
