<?php
session_start();
include 'db.php';

if (!isset($_GET['id'])) {
    die("Blog not found.");
}

$blog_id = $_GET['id'];

// Fetch the blog post
$sql = "SELECT blogs.*, users.name FROM blogs 
        JOIN users ON blogs.user_id = users.id 
        WHERE blogs.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$result = $stmt->get_result();
$blog = $result->fetch_assoc();

// Fetch likes
$likes_sql = "SELECT users.name FROM likes 
              JOIN users ON likes.user_id = users.id 
              WHERE likes.blog_id = ?";
$stmt = $conn->prepare($likes_sql);
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$likes = $stmt->get_result();

// Fetch comments
$comment_sql = "SELECT comments.*, users.name FROM comments 
                JOIN users ON comments.user_id = users.id 
                WHERE comments.blog_id = ? 
                ORDER BY comments.created_at DESC";
$stmt = $conn->prepare($comment_sql);
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$comments = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($blog['title']); ?></title>
    <style>
       body {
    font-family: 'Poppins', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    min-height: 100vh; /* Ensures the body grows as needed */
    overflow: auto; /* Enables scrolling for overflow content */
    display: flex;
    justify-content: center;
    align-items: flex-start; /* Content starts at the top */
}

.container {
    background: #fff;
    padding: 30px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    width: 90%; /* Adjust the width to fit smaller screens dynamically */
    max-width: 600px; /* Prevent the content from stretching too wide */
    margin: 20px auto; /* Adds spacing from the edges */
    text-align: center;
}

h2 {
    margin-bottom: 20px;
    color: #333;
}

p {
    line-height: 1.6;
    text-align: justify;
    color: #555;
}

input, textarea {
    width: 100%;
    height: 40px; /* Adjusted for input box */
    margin: 10px 0;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 10px;
    background: #ff6b6b;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease;
}

button:hover {
    background: #e05252;
}

a {
    color: #ff6b6b;
    text-decoration: none;
    font-weight: bold;
    display: inline-block;
    margin-top: 20px;
}


.btn,
.like-btn {
    width: 200px;
    padding: 10px;
    margin: 15px auto;
    color: #fff;
    background: #007BFF;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease;
}

.btn:hover,
.like-btn:hover {
    background: #0056b3;
}

.comment {
    padding: 15px;
    border-bottom: 1px solid #ddd;
    text-align: left;
    margin-bottom: 10px;
    border-radius: 5px;
    background: #f9f9f9;
}

    </style>
</head>
<body>
    <div class="container">
        <h2><?= htmlspecialchars($blog['title']); ?></h2>
        <p><strong>By:</strong> <?= htmlspecialchars($blog['name']); ?></p>
        <p><?= nl2br(htmlspecialchars($blog['content'])); ?></p>

        <!-- Like Button -->
        <button class="like-btn" id="btn" data-blog-id="<?= $blog['id']; ?>" data-user-id="<?= $_SESSION['user_id'] ?? ''; ?>">Like</button>

        
        
        <!-- Host-Specific Options -->
        <?php if ($_SESSION['user_id'] == $blog['user_id']) { ?>
            <div class="host-options">
                <a class="btn" href="edit.php?id=<?= $blog['id']; ?>" >Edit</a>
                <a class="btn" href="delete.php?id=<?= $blog['id']; ?>" onclick="return confirm('Are you sure you want to delete this blog?');">Delete</a>
            </div>
            <?php } ?>

            <!-- Display Likes -->
            <div id="likes-<?= $blog['id']; ?>">
                <p><strong>Liked by:</strong> 
                    <?= $likes->num_rows > 0 ? implode(", ", array_column($likes->fetch_all(MYSQLI_ASSOC), 'name')) : "No likes yet"; ?>
                </p>
            </div>

        <hr>

        <!-- Comments Section -->
        <h3>Comments</h3>
        <div id="comments-<?= $blog['id']; ?>">
            <?php while ($comment = $comments->fetch_assoc()) { ?>
                <div class="comment">
                    <p><strong><?= htmlspecialchars($comment['name']); ?>:</strong> <?= htmlspecialchars($comment['comment_text']); ?></p>
                </div>
            <?php } ?>
        </div>

        <!-- Add Comment Form -->
        <?php if (isset($_SESSION['user_id'])) { ?>
            <form class="comment-form" method="POST">
                <input type="hidden" name="blog_id" value="<?= $blog['id']; ?>">
                <input type="hidden" name="user_id" value="<?= $_SESSION['user_id']; ?>">
                <input name="comment_text" required placeholder="Add a comment">
                <button type="submit">Comment</button>
            </form>
        <?php } else { ?>
            <p><a href="login.php">Login to comment</a></p>
        <?php } ?>

        <a href="dashboard.php">Back to Home</a>
    </div>

    <script src="script.js"></script>
</body>
</html>
