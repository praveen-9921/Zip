<?php
$host = "localhost";
$user = "root";
$password = "9990201523p";
$dbname = "blog_db";

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
