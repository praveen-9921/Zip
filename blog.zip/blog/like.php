<?php
session_start();
include 'db.php';

if (!isset($_POST['blog_id']) || !isset($_POST['user_id'])) {
    exit("Invalid request.");
}

$blog_id = $_POST['blog_id'];
$user_id = $_POST['user_id'];

// Check if user already liked the post
$check_like = $conn->prepare("SELECT * FROM likes WHERE blog_id = ? AND user_id = ?");
$check_like->bind_param("ii", $blog_id, $user_id);
$check_like->execute();
$result = $check_like->get_result();

if ($result->num_rows == 0) {
    // Insert Like
    $stmt = $conn->prepare("INSERT INTO likes (blog_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $blog_id, $user_id);
    $stmt->execute();
}

// Fetch updated likes
$likes = $conn->prepare("SELECT users.name FROM likes JOIN users ON likes.user_id = users.id WHERE likes.blog_id = ?");
$likes->bind_param("i", $blog_id);
$likes->execute();
$likes_result = $likes->get_result();

echo "<p><strong>Liked by:</strong> " . ($likes_result->num_rows > 0 ? implode(", ", array_column($likes_result->fetch_all(MYSQLI_ASSOC), 'name')) : "No likes yet") . "</p>";
?>
