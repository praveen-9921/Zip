<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$blog_id = $_GET['id'];

// Check if the user is the owner of the blog
$sql = "SELECT * FROM blogs WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $blog_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Unauthorized action.";
    exit();
}

// Delete the blog
$delete_sql = "DELETE FROM blogs WHERE id = ?";
$stmt = $conn->prepare($delete_sql);
$stmt->bind_param("i", $blog_id);
if ($stmt->execute()) {
    header("Location: dashboard.php");
    exit();
} else {
    echo "Error deleting blog.";
}
?>
